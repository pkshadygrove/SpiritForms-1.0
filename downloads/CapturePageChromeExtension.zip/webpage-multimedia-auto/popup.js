document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("capture");
    const status = document.getElementById("status");

    btn.addEventListener("click", () => {
        status.textContent = "Starting capture…";

        chrome.runtime.sendMessage({ action: "RUN_ZIP_CAPTURE" }, () => {
            const err = chrome.runtime.lastError;
            if (err) {
                status.textContent = "Error: " + err.message;
            }
        });
    });

    chrome.runtime.onMessage.addListener((msg) => {
        if (!msg || msg.action !== "CAPTURE_PROGRESS") return;

        if (msg.message) {
            status.textContent = msg.message;
        }
    });
});

// content_script.js
// Runs in the about:blank report tab.
// Does NOT modify the page. It just snapshots HTML + media URLs and
// sends them to the background script.

(function () {
    console.log("CONTENT: starting capture");

    // Prevent double-injection in the same tab
    if (window.__SPIRITFORM_CAPTURE_RUNNING__) {
        console.log("CONTENT: already running, skipping");
        return;
    }
    window.__SPIRITFORM_CAPTURE_RUNNING__ = true;

    function getZipBaseName() {
        try {
            const meta = document.getElementById("spiritforms-report-meta");
            if (meta && meta.dataset && meta.dataset.zipBaseName) {
                return meta.dataset.zipBaseName;
            }
        } catch (e) {
            console.warn("CONTENT: could not read report meta", e);
        }

        try {
            const title = (document.title || "").trim();
            if (title) return title;
        } catch (e) {
            console.warn("CONTENT: could not read document title", e);
        }

        return "SpiritForms_Report";
    }

    (async () => {
        try {
            // 1) Capture full HTML from current page (about:blank report)
            const pageHtml = document.documentElement.outerHTML;

            // 2) Collect media refs: { abs, ref }
            const resources = [];
            const seen = new Set();

            const elements = document.querySelectorAll("img, audio, video, source, a");

            for (const el of elements) {
                let rawAttr = null;   // how it appears in HTML (relative)
                let abs = null;       // absolute URL for fetch

                if (el.tagName === "A") {
                    rawAttr = el.getAttribute("href");
                    if (!rawAttr) continue;
                    try {
                        abs = new URL(rawAttr, document.baseURI).href;
                    } catch (e) {
                        console.warn("CONTENT: bad href:", rawAttr, e);
                        continue;
                    }
                } else {
                    // img, audio, video, source
                    rawAttr = el.getAttribute("src") || el.getAttribute("poster");
                    if (!rawAttr) continue;
                    try {
                        // Prefer currentSrc/src/poster if available, else resolve raw
                        abs = el.currentSrc || el.src || el.poster || new URL(rawAttr, document.baseURI).href;
                    } catch (e) {
                        console.warn("CONTENT: bad media attr:", rawAttr, e);
                        continue;
                    }
                }

                if (!abs || !rawAttr) continue;

                const key = abs + "||" + rawAttr;
                if (seen.has(key)) continue;
                seen.add(key);

                resources.push({ abs, ref: rawAttr });
            }

            const zipBaseName = getZipBaseName();

            console.log("CONTENT: Sending PAGE_SNAPSHOT with", resources.length, "resources");

            // 3) Send snapshot to background for ZIP building
            chrome.runtime.sendMessage({
                action: "PAGE_SNAPSHOT",
                html: pageHtml,
                resources,
                zipBaseName
            });

        } catch (err) {
            console.error("CONTENT FATAL ERROR:", err);
        }
    })();
})();

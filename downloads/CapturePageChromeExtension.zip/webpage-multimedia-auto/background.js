// background.js — MV3 service worker
importScripts("jszip.min.js");

console.log("BACKGROUND LOADED:", new Date().toISOString());

// ---------------- CONFIG (tweak if you want) ----------------
const MAX_CONCURRENT_DOWNLOADS = 3;   // how many files to fetch at once
const MAX_RETRIES = 3;                // per file
const FETCH_TIMEOUT_MS = 30000;       // 30s per attempt

// ---------------- Utility: Blob → data URL ------------------
function blobToDataURL(blob) {
    return new Promise((resolve, reject) => {
        try {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        } catch (err) {
            reject(err);
        }
    });
}

// ---------------- Utility: send progress to popup -----------
function sendProgress(update) {
    chrome.runtime.sendMessage({
        action: "CAPTURE_PROGRESS",
        ...update
    }, () => {
        // Ignore errors if no listeners (e.g. popup closed)
        const err = chrome.runtime.lastError;
        if (err) {
            // console.log("No progress listener:", err.message);
        }
    });
}

// ---------------- Utility: fetch with timeout + retry -------
async function fetchWithRetry(url, options = {}, maxRetries = MAX_RETRIES) {
    let lastError = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

            const resp = await fetch(url, { ...options, signal: controller.signal });
            clearTimeout(timeoutId);

            if (!resp || !resp.ok) {
                throw new Error(`HTTP ${resp ? resp.status : "no response"}`);
            }

            return resp;
        } catch (err) {
            lastError = err;
            console.warn(`Fetch attempt ${attempt} failed for ${url}:`, err);

            if (attempt === maxRetries) {
                throw lastError;
            }
        }
    }

    throw lastError;
}

// ---------------- Message handler ---------------------------
chrome.runtime.onMessage.addListener((msg, sender) => {
    if (!msg || !msg.action) return;

    // Popup → start capture
    if (msg.action === "RUN_ZIP_CAPTURE") {
        sendProgress({
            stage: "starting",
            message: "Starting capture…"
        });

        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
            const tab = tabs[0];
            if (!tab) return;

            chrome.scripting.executeScript(
                {
                    target: { tabId: tab.id },
                    files: ["content_script.js"]
                },
                () => {
                    if (chrome.runtime.lastError) {
                        console.error("INJECTION ERROR:", chrome.runtime.lastError);
                        sendProgress({
                            stage: "error",
                            message: "Failed to inject capture script."
                        });
                    } else {
                        console.log("BACKGROUND: content_script.js injected");
                        sendProgress({
                            stage: "scanning",
                            message: "Scanning page for media…"
                        });
                    }
                }
            );
        });

        return;
    }

    // Content script → snapshot
    if (msg.action === "PAGE_SNAPSHOT") {
        console.log("BACKGROUND: PAGE_SNAPSHOT received");

        const rawHTML = msg.html || "<html></html>";
        const resources = msg.resources || [];
        const total = resources.length;
        const requestedZipBaseName = String(msg.zipBaseName || "SpiritForms_Report");

        function sanitizeFilenamePart(value) {
            return String(value || "")
                .trim()
                .replace(/[\\/:*?"<>|]+/g, "_")
                .replace(/\s+/g, "_")
                .replace(/_+/g, "_")
                .replace(/^_+|_+$/g, "");
        }

        const zipBaseName = sanitizeFilenamePart(requestedZipBaseName) || "SpiritForms_Report";

        console.log("BACKGROUND: Resource count =", total);

        sendProgress({
            stage: "downloading",
            message: total > 0
                ? `Found ${total} media files. Downloading…`
                : "No media found. Building report…",
            total,
            completed: 0,
            skipped: 0
        });

        (async () => {
            try {
                if (typeof JSZip === "undefined") {
                    console.error("BACKGROUND: JSZip is not available.");
                    sendProgress({
                        stage: "error",
                        message: "JSZip not found in background."
                    });
                    return;
                }

                const zip = new JSZip();
                const mediaFolder = zip.folder("media");
                const rewriteMap = new Map();

                let completed = 0;
                let skipped = 0;

                // -------------- Helper: process a single resource --------------
                const processResource = async (res) => {
                    if (!res || !res.abs || !res.ref) return;

                    const absUrl = res.abs;
                    const ref = res.ref;

                    if (rewriteMap.has(ref)) {
                        // Already downloaded/mapped
                        return;
                    }

                    console.log("BACKGROUND: Fetching", absUrl);

                    try {
                        const resp = await fetchWithRetry(absUrl, {
                            credentials: "include",
                            redirect: "follow",
                            mode: "no-cors"
                        });

                        const blob = await resp.blob();
                        if (!blob || blob.size === 0) {
                            console.warn("BACKGROUND: Empty blob skipped:", absUrl);
                            skipped++;
                            return;
                        }

                        if (blob.type.includes("text/html")) {
                            console.warn("BACKGROUND: HTML blob skipped:", absUrl);
                            skipped++;
                            return;
                        }

                        let clean = absUrl.split(/[?#]/)[0];
                        let ext = clean.split(".").pop().toLowerCase().replace(/[^a-z0-9]/gi, "");
                        if (!ext) ext = "bin";

                        const filename = `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
                        mediaFolder.file(filename, blob);
                        rewriteMap.set(ref, `media/${filename}`);

                        completed++;
                        sendProgress({
                            stage: "downloading",
                            message: `Downloading media… (${completed}/${total}, skipped: ${skipped})`,
                            total,
                            completed,
                            skipped
                        });

                    } catch (err) {
                        console.warn("BACKGROUND: Final fetch failure, skipping:", absUrl, err);
                        skipped++;
                        sendProgress({
                            stage: "downloading",
                            message: `Skipping failed media… (${completed}/${total}, skipped: ${skipped})`,
                            total,
                            completed,
                            skipped
                        });
                    }
                };

                // -------------- Concurrency controller --------------
                const queue = resources.slice(); // shallow copy
                const workers = [];

                const worker = async () => {
                    while (queue.length > 0) {
                        const res = queue.shift();
                        await processResource(res);
                    }
                };

                const workerCount = Math.min(MAX_CONCURRENT_DOWNLOADS, Math.max(1, total));
                for (let i = 0; i < workerCount; i++) {
                    workers.push(worker());
                }

                await Promise.all(workers);

                // -------------- Logo injection --------------
                let finalHTML = rawHTML;

                try {
                    const logoUrl = chrome.runtime.getURL("logo_small.png");
                    const resp = await fetch(logoUrl);

                    if (resp && resp.ok) {
                        const logoBlob = await resp.blob();
                        mediaFolder.file("logo_small.png", logoBlob);

                        const marker =
                            '<div style="font-size:22px;font-weight:bold;">SpiritForm Report</div>';

                        const replacement =
                            '<div style="display:flex;align-items:center;">' +
                            
                            '<div style="font-size:22px;font-weight:bold;">SpiritForm Report</div>' +
                            '</div>';

                        finalHTML = finalHTML.replace(marker, replacement);

                    } else {
                        console.warn("BACKGROUND: logo_small.png not found");
                    }

                } catch (e) {
                    console.warn("BACKGROUND: Error adding logo:", e);
                }

                // -------------- Rewrite media URLs --------------
                console.log("BACKGROUND: Rewriting references…");

                for (const [ref, newPath] of rewriteMap.entries()) {
                    const safe = ref.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                    finalHTML = finalHTML.replace(new RegExp(safe, "g"), newPath);
                }

                // -------------- Append footer --------------
                const version = chrome.runtime.getManifest().version || "1.0";
                const today = new Date().toISOString().slice(0, 10);

                const footerHTML =
                    '<hr style="margin-top:40px;border:0;border-top:1px solid #bbb;">' +
                    '<div style="text-align:center;font-family:Arial,sans-serif;' +
                    'font-size:11px;font-style:italic;color:#444;margin-top:6px;">' +
                    `Generated by SpiritForm Capture Extension (v${version} — ${today})` +
                    '</div>';

                finalHTML = finalHTML + footerHTML;

                // -------------- Add Report.html to ZIP --------------
                zip.file("Report.html", finalHTML);

                // -------------- Build ZIP + download --------------
                sendProgress({
                    stage: "zipping",
                    message: "Building ZIP archive. Please wait...",
                    total,
                    completed,
                    skipped
                });

                console.log("BACKGROUND: Generating ZIP…");

                const zipBlob = await zip.generateAsync({ type: "blob" });
                const dataUrl = await blobToDataURL(zipBlob);

                chrome.downloads.download({
                    url: dataUrl,
                    filename: `${zipBaseName}.zip`,
                    conflictAction: "uniquify"
                });

                sendProgress({
                    stage: "done",
                    message: "Capture complete. ZIP download in progress. Please wait...",
                    total,
                    completed,
                    skipped
                });

            } catch (err) {
                console.error("BACKGROUND ERROR:", err);
                sendProgress({
                    stage: "error",
                    message: "Error during capture. See extension console for details."
                });
            }
        })();

        return;
    }
});

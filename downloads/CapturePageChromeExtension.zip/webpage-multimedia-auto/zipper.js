// Runs in PAGE context. JSZip is visible here.

if (window.__ZIPPER_LOADED__) {
    console.log("ZIPPER: Already loaded");
} else {
    window.__ZIPPER_LOADED__ = true;
}

window.capturePageWithZip = async function() {
    if (window.__ALREADY_CAPTURING__) {
        console.log("ZIPPER: Capture already in progress, skipping");
        return;
    }
    window.__ALREADY_CAPTURING__ = true;

    console.log("PAGE: capturePageWithZip() running");

    try {
        const zip = new JSZip();

        zip.file("page.html", document.documentElement.outerHTML);

        const els = document.querySelectorAll("img, audio, video, source");
        const urls = Array.from(els)
            .map(el => el.src || el.currentSrc)
            .filter(Boolean);

        console.log("PAGE: media URLs:", urls);

        for (const url of urls) {
            try {
                const resp = await fetch(url, {
                    credentials: "include",
                    redirect: "follow"
                });
                if (!resp.ok) continue;

                const buf = await resp.arrayBuffer();
                const ext = url.split(".").pop().split(/[#?]/)[0] || "bin";

                zip.file(
                    `media/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`,
                    buf
                );

                console.log("PAGE: added", url);

            } catch (e) {
                console.warn("PAGE: failed", url, e);
            }
        }

        console.log("PAGE: generating ZIP");

        const blob = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(blob);

        console.log("PAGE: ZIP ready");

        window.postMessage({ type: "ZIP_READY", url }, "*");

    } catch (err) {
        console.error("PAGE ERROR:", err);
    }
};

window.addEventListener("message", (event) => {
    if (event.data && event.data.type === "RUN_CAPTURE") {
        window.capturePageWithZip();
    }
});

Capture Page Chrome Extension
Installation and Usage

This Chrome extension will allow you to download a .zip file of the text and multimedia items of your SpiritForm report. You can then browse the report on your computer at your leisure.

Installation instructions:

Step 1. Unzip all of the files from the CapturePageChromeExtension.zip file. 

In Winzip,  select all of the files and click 'Extract'.
Select 'All files/folders in archive' radio button.
Select 'Use folder names' checkbox.
Click 'Extract'.

You should now have two new folders:
 C:\webpage-multimedia-auto\
 C:\webpage-multimedia-auto\custom

Step 2. In Chrome:
Enter 'chrome://extensions/' in the browser address bar
Go to Extensions >> Developer Mode and enable it (enable the toggle button in the far upper right corner)

'Developer Mode' MUST be enabled for this extension to work!

Step 3. Click 'Load unpacked'

Step 4. Select the 'C:\webpage-multimedia-auto\' folder. 

Step 5. Enable the extension by clicking on the dot in the lower right corner of the extension.

Step 6. In the chrome://extensions/ window, click the 'Details' button of the SpiritForm Capture Extension.

Step 7. Scroll down to find the 'Pin to Toolbar' button. Enable it.

USAGE:

1. Log in to nuBuilder. 
2. Select 'Case Reports'  
3. Select the investigation. A window will open showing the case number and a 'View Report' button. Click the 'View Report' button and an 'about.blank' browser tab will open and you will see the report for the investigation you selected.
4. In the upper right of the Chrome address bar, click the 'S' icon and then click the 'Capture page as ZIP' button. You will see the progress of the download and .zip file creation.
5. You should be automatically prompted to save the .zip file when the download and .zip packaging has completed. The .zip file should be named something like Case_Name_Here_Investigation_3_April_14_2026.zip.
6. Once you have downloaded the file, unzip the files into a new folder on your computer and then open the 'Report.html' document in Chrome to view the report.
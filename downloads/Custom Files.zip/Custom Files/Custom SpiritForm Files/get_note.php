<?php
require_once('../core/nuconfig.php');   // Correct bootstrap file

$note_id = $_GET['id'] ?? '';

$sql = "
    SELECT not_content 
    FROM zzzzsys_note
    WHERE zzzzsys_note_id = ?
";

$rows = nuRunQuery($sql, [$note_id]);

if (count($rows) > 0) {
    echo $rows[0]['not_content'];
} else {
    echo '';
}
?>
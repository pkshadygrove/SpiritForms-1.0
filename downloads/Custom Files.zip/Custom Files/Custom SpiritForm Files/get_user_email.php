<?php

require_once __DIR__ . '/../nuconfig.php';
require_once __DIR__ . '/../core/nucommon.php';

$id = isset($_GET['id']) ? $_GET['id'] : '';

$email = '';

if ($id !== '') {

    $sql  = "SELECT sus_email FROM zzzzsys_user WHERE zzzzsys_user_id = ?";
    $stmt = nuRunQuery($sql, [$id]);   // PDOStatement in your nuBuilder

    if ($stmt) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && isset($row['sus_email'])) {
            $email = $row['sus_email'];
        }
    }
}

header('Content-Type: text/plain; charset=UTF-8');
echo $email;
